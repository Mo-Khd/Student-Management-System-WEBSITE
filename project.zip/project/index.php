<?php
header("location: results/index.php");
exit;
?>