 <?php
 $db = mysqli_connect("localhost","root","","project"); // کۆنێکت بوون بە داتابایسەوە
 ?>